package phonebookapp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PhonebookGUI extends JFrame {
    private Phonebook phonebook;
    private JTextArea displayArea;
    private JTextField nameField, phoneField, oldNameField, newNameField;

    public PhonebookGUI() {
        phonebook = new Phonebook();
        setTitle("Phonebook App");
        setSize(400, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Text area to display contacts
        displayArea = new JTextArea();
        displayArea.setEditable(false);
        add(new JScrollPane(displayArea), BorderLayout.CENTER);

        // Panel for input fields
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(5, 2));

        // Input fields
        inputPanel.add(new JLabel("Name:"));
        nameField = new JTextField();
        inputPanel.add(nameField);

        inputPanel.add(new JLabel("Phone Number:"));
        phoneField = new JTextField();
        inputPanel.add(phoneField);

        inputPanel.add(new JLabel("Old Name:"));
        oldNameField = new JTextField();
        inputPanel.add(oldNameField);

        inputPanel.add(new JLabel("New Name:"));
        newNameField = new JTextField();
        inputPanel.add(newNameField);

        add(inputPanel, BorderLayout.NORTH);

        // Buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(2, 4));

        JButton insertButton = new JButton("Insert");
        insertButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                String phone = phoneField.getText();
                phonebook.insertContact(name, phone);
                updateDisplay();
            }
        });
        buttonPanel.add(insertButton);

        JButton searchButton = new JButton("Search");
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                Contact contact = phonebook.searchContact(name);
                if (contact != null) {
                    displayArea.setText("Found: " + contact.name + ": " + contact.phoneNumber);
                } else {
                    displayArea.setText("Contact not found.");
                }
            }
        });
        buttonPanel.add(searchButton);

        JButton displayButton = new JButton("Display All");
        displayButton.addActionListener(e -> updateDisplay());
        buttonPanel.add(displayButton);

        JButton deleteButton = new JButton("Delete");
        deleteButton.addActionListener(e -> {
            String name = nameField.getText();
            phonebook.deleteContact(name);
            updateDisplay();
        });
        buttonPanel.add(deleteButton);

        JButton updateButton = new JButton("Update");
        updateButton.addActionListener(e -> {
            String oldName = oldNameField.getText();
            String newName = newNameField.getText();
            String phone = phoneField.getText();
            phonebook.updateContact(oldName, newName, phone);
            updateDisplay();
        });
        buttonPanel.add(updateButton);

        JButton sortButton = new JButton("Sort");
        sortButton.addActionListener(e -> {
            phonebook.sortContacts();
            updateDisplay();
        });
        buttonPanel.add(sortButton);

        JButton analyzeButton = new JButton("Analyze");
        analyzeButton.addActionListener(e -> {
            String name = nameField.getText();
            phonebook.analyzeSearchEfficiency(name);
        });
        buttonPanel.add(analyzeButton);

        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void updateDisplay() {
        displayArea.setText("");
        for (Contact contact : phonebook.contacts) {
            displayArea.append(contact.name + ": " + contact.phoneNumber + "\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            PhonebookGUI gui = new PhonebookGUI();
            gui.setVisible(true);
        });
    }
}

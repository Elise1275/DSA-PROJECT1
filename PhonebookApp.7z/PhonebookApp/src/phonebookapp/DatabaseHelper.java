
package phonebookapp;


import java.sql.*;
import java.util.Scanner;

public class DatabaseHelper {
    private static final String URL = "jdbc:sqlite:phonebook.db";

    public static Connection connect() {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(URL);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return conn;
    }

    public static void createTable() {
        String sql = "CREATE TABLE IF NOT EXISTS contacts ("
                + " id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + " name TEXT NOT NULL,"
                + " phone_number TEXT NOT NULL"
                + ");";
        try (Connection conn = connect();
             Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
            System.out.println("Table created successfully.");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void insertContact(String name, String phoneNumber) {
        String sql = "INSERT INTO contacts (name, phone_number) VALUES (?, ?)";
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setString(2, phoneNumber);
            pstmt.executeUpdate();
            System.out.println("Contact added successfully.");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void displayContacts() {
        String sql = "SELECT * FROM contacts";
        try (Connection conn = connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            System.out.println("Contacts:");
            while (rs.next()) {
                System.out.println(rs.getString("name") + ": " + rs.getString("phone_number"));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void searchContact(String name) {
        String sql = "SELECT * FROM contacts WHERE name = ?";
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                System.out.println("Found: " + rs.getString("name") + ": " + rs.getString("phone_number"));
            } else {
                System.out.println("Contact not found.");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String[] args) {
        createTable(); // Ensure the contacts table is created

        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\nPhonebook Menu:");
            System.out.println("1. Insert Contact");
            System.out.println("2. Display All Contacts");
            System.out.println("3. Search Contact");
            System.out.println("0. Exit");
            System.out.print("Choose an option: ");
            choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Phone Number: ");
                    String phoneNumber = scanner.nextLine();
                    insertContact(name, phoneNumber);
                    break;

                case 2:
                    displayContacts();
                    break;

                case 3:
                    System.out.print("Enter Name to Search: ");
                    name = scanner.nextLine();
                    searchContact(name);
                    break;

                case 0:
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid option. Try again.");
            }
        } while (choice != 0);

        scanner.close();
    }
}

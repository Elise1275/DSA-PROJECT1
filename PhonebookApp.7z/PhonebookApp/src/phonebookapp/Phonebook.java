
package phonebookapp;

import java.util.ArrayList;


public class Phonebook {
    private Contact head;
    Iterable<Contact> contacts;

    public Phonebook() {
        this.head = null;
    }

    // Insert Contact
    public void insertContact(String name, String phoneNumber) {
        Contact newContact = new Contact(name, phoneNumber);
        if (head == null) {
            head = newContact;
        } else {
            Contact current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newContact;
        }
    }

    // Search Contact
    public Contact searchContact(String name) {
        Contact current = head;
        while (current != null) {
            if (current.name.equals(name)) {
                return current;
            }
            current = current.next;
        }
        return null;  // Not found
    }

    // Display All Contacts
    public void displayContacts() {
        Contact current = head;
        while (current != null) {
            System.out.println(current.name + ": " + current.phoneNumber);
            current = current.next;
        }
    }

    // Delete Contact
    public void deleteContact(String name) {
        if (head == null) return;  // Phonebook1 is empty

        if (head.name.equals(name)) {
            head = head.next;  // Remove head
            return;
        }

        Contact previous = null;
        Contact current = head;
        while (current != null && !current.name.equals(name)) {
            previous = current;
            current = current.next;
        }

        if (current != null) {
            previous.next = current.next;  // Bypass the node to delete it
        }
    }

    // Update Contact
    public void updateContact(String oldName, String newName, String newPhoneNumber) {
        Contact contact = searchContact(oldName);
        if (contact != null) {
            contact.name = newName;
            contact.phoneNumber = newPhoneNumber;
        } else {
            System.out.println("Contact not found.");
        }
    }

    // Optional: Sort Contacts
    public void sortContacts() {
        if (head == null || head.next == null) return;  // No need to sort

        // Convert linked list to array
        ArrayList<Contact> contactsArray = new ArrayList<>();
        Contact current = head;
        while (current != null) {
            contactsArray.add(current);
            current = current.next;
        }

        // Sort using a simple sort (e.g., bubble sort)
        for (int i = 0; i < contactsArray.size() - 1; i++) {
            for (int j = 0; j < contactsArray.size() - i - 1; j++) {
                if (contactsArray.get(j).name.compareTo(contactsArray.get(j + 1).name) > 0) {
                    // Swap
                    Contact temp = contactsArray.get(j);
                    contactsArray.set(j, contactsArray.get(j + 1));
                    contactsArray.set(j + 1, temp);
                }
            }
        }

        // Reconstruct the linked list from the sorted array
        head = contactsArray.get(0);
        current = head;
        for (int i = 1; i < contactsArray.size(); i++) {
            current.next = contactsArray.get(i);
            current = current.next;
        }
        current.next = null;  // Terminate the list
    }

    // Analyze Search Efficiency
    public void analyzeSearchEfficiency(String name) {
        long startTime = System.nanoTime();
        Contact result = searchContact(name);
        long endTime = System.nanoTime();
        long elapsedTime = endTime - startTime;

        System.out.println("Search time: " + elapsedTime + " nanoseconds");
        if (result != null) {
            System.out.println("Found: " + result.name + ": " + result.phoneNumber);
        } else {
            System.out.println("Contact not found.");
        }
    }
}



package phonebookapp;

import java.util.Scanner;

public class PhonebookApp {
    public static void main(String[] args) {
        Phonebook phonebook = new Phonebook();
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("Phonebook Menu:");
            System.out.println("1. Insert Contact");
            System.out.println("2. Search Contact");
            System.out.println("3. Display All Contacts");
            System.out.println("4. Delete Contact");
            System.out.println("5. Update Contact");
            System.out.println("6. Sort Contacts");
            System.out.println("7. Analyze Search Efficiency");
            System.out.println("0. Exit");
            System.out.print("Choose an option: ");
            choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Phone Number: ");
                    String phoneNumber = scanner.nextLine();
                    phonebook.insertContact(name, phoneNumber);
                    break;

               case 2:
                    System.out.print("Enter Name to Search: ");
                    name = scanner.nextLine();
                    Contact contact = phonebook.searchContact(name);
                    if (contact != null) {
                        System.out.println("Found: " + contact.name + ": " + contact.phoneNumber);
                    } else {
                        System.out.println("Contact not found.");
                    }
                    break;

                case 3:
                    phonebook.displayContacts();
                    break;

                case 4:
                    System.out.print("Enter Name to Delete: ");
                    name = scanner.nextLine();
                    phonebook.deleteContact(name);
                    break;

                case 5:
                    System.out.print("Enter Old Name: ");
                    String oldName = scanner.nextLine();
                    System.out.print("Enter New Name: ");
                    String newName = scanner.nextLine();
                    System.out.print("Enter New Phone Number: ");
                    String newPhoneNumber = scanner.nextLine();
                    phonebook.updateContact(oldName, newName, newPhoneNumber);
                    break;

                case 6:
                    phonebook.sortContacts();
                    System.out.println("Contacts sorted.");
                    break;

                case 7:
                    System.out.print("Enter Name to Analyze Search Efficiency: ");
                    name = scanner.nextLine();
                    phonebook.analyzeSearchEfficiency(name);
                    break;

                case 0:
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid option. Try again.");
            }
        } while (choice != 0);

        scanner.close();
    }
}

       
    
    

